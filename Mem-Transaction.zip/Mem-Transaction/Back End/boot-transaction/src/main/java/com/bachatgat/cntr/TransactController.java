package com.bachatgat.cntr;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bachatgat.dto.Transact;
import com.bachatgat.service.TransactService;

@CrossOrigin(origins="http://localhost:4200")

@RestController
public class TransactController {

	@Autowired
	private TransactService tranService;
	
	
	
		@PostMapping(value="trans_add")
		public String transactAdd(@RequestBody Transact transact) {
			tranService.addTransaction(transact);
			return "Transaction is a success";
		}
		
		@GetMapping(value="trans_list")
		public List<Transact> transactList(){
			return tranService.getAll();
		}
		
		@DeleteMapping(value="trans_del/{id}")
		public String transDelete(@PathVariable int id) {
			tranService.removeTransaction(id);
			return "Transaction deleted successfully";
		}
		
		@GetMapping(value="trans_get/{id}")
		public Transact getTransact(@PathVariable int id) {
			return tranService.getTransaction(id);
		}
		
		@PutMapping(value="trans_update")
		public String transUpdate(@RequestBody Transact transact) {
			tranService.updateTransaction(transact);
			return "Transaction updated successfully";
		}
		
		
		
}
