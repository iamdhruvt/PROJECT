package com.bachatgat.service;

import java.util.List;

import com.bachatgat.dto.Transact;

public interface TransactService {
	
	
	public void addTransaction(Transact transact);
	public void removeTransaction(int id);
	public Transact getTransaction(int id);
	public void updateTransaction(Transact transact);
	public List<Transact> getAll();
}
