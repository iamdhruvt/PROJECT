package com.bachatgat.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bachatgat.dto.Transact;

@Repository
public interface TransactRepository extends CrudRepository<Transact, Integer>{

}
