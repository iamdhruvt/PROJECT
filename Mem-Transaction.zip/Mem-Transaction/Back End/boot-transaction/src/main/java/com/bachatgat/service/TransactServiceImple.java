package com.bachatgat.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bachatgat.dto.Transact;
import com.bachatgat.repo.TransactRepository;

@Service
public class TransactServiceImple implements TransactService {
	
	@Autowired
	private TransactRepository transactRepository;

	@Override
	public void addTransaction(Transact transact) {
		transactRepository.save(transact);
		
	}

	@Override
	public void removeTransaction(int id) {
		transactRepository.deleteById(id);
		
	}

	@Override
	public Transact getTransaction(int id) {
		Optional<Transact> opt=transactRepository.findById(id);
		
		return opt.get();
	}

	@Override
	public void updateTransaction(Transact transact) {
		transactRepository.save(transact);
		
	}

	@Override
	public List<Transact> getAll() {
		Iterable<Transact> itr=transactRepository.findAll();
		Iterator<Transact> it=itr.iterator();
		List<Transact> li=new ArrayList<Transact>();
		while(it.hasNext()) {
			li.add(it.next());
		}
		return li;
	}

}
