package com.bachatgat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootTransactionApplication.class, args);
	}

}
