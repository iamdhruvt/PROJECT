export class Transaction {
  mem_id: number;
  acc_bal: number;
  loan: number;
}
