import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactAddComponent } from './transact-add.component';

describe('TransactAddComponent', () => {
  let component: TransactAddComponent;
  let fixture: ComponentFixture<TransactAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransactAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TransactAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
