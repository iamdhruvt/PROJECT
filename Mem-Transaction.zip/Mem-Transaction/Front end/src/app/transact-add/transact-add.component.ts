import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transaction } from '../transaction';
import { TranserviceService } from '../transervice.service';

@Component({
  selector: 'app-transact-add',
  templateUrl: './transact-add.component.html',
  styleUrls: ['./transact-add.component.css']
})
export class TransactAddComponent implements OnInit {
  transaction: Transaction=new Transaction();
mem_id;
acc_bal;
loan;
  constructor(private tranService:TranserviceService,private router: Router) { }

  ngOnInit(): void {
   // this.getMember();
   // this.updatetransaction();
  }
  /*private getMember(){
    this.tranService.getMember(15).subscribe(data=>{
      this.mem_id=data.mem_id;
      this.acc_bal=data.acc_bal;
      this.loan=data.loan;
      //this.transaction=data;
    })
  }
*/
  updatetransaction(){
    this.tranService.applyloan(this.transaction).subscribe(data=>{
      this.router.navigate(['/home']);
    //this.gotoTransactList();
    })
  }

  gotoTransactList(){
    this.router.navigate(['/home']);
  }
onSubmit(){
/*this.loan=this.transaction.loan;
this.acc_bal=this.transaction.acc_bal;
this.acc_bal=this.acc_bal+this.loan;
console.log(this.acc_bal);*/
  console.log(this.transaction);
  this.updatetransaction();
}
}
