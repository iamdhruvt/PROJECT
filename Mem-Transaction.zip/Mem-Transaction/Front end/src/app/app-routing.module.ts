import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransactAddComponent } from './transact-add/transact-add.component';
import { TransactHomeComponent } from './transact-home/transact-home.component';
import { TransactListComponent } from './transact-list/transact-list.component';

const routes: Routes = [
  {path :'home', component: TransactHomeComponent},

  {path: '',redirectTo:'home',pathMatch:'full'},
  {path: 'add-transaction',component: TransactAddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
