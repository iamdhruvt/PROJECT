import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { TranserviceService } from '../transervice.service';

@Component({
  selector: 'app-transact-home',
  templateUrl: './transact-home.component.html',
  styleUrls: ['./transact-home.component.css']
})
export class TransactHomeComponent implements OnInit {
  transaction: Transaction[];
  mem_id;
  acc_bal;
  loan;
  total_loan=0;
  group_bal=0;
  constructor(private tranService:TranserviceService) { }

  ngOnInit(): void {
   this.getTransaction();
   this.getMember();
  }
  private getTransaction(){
    this.tranService.getTransactionList().subscribe(data =>{
      this.transaction=data;
      for(let i=0;i<this.transaction.length;i++){
        this.group_bal=this.group_bal+this.transaction[i].acc_bal;
        this.total_loan=this.total_loan+this.transaction[i].loan;


      }
      this.group_bal=this.group_bal-this.total_loan;
    }
    );

  }

  private getMember(){
    this.tranService.getMember(15).subscribe(data=>{
      this.mem_id=data.mem_id;
      this.acc_bal=data.acc_bal;
      this.loan=data.loan;
    })
  }
  }


